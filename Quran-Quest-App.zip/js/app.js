const NAV_ITEMS = [
  { page: 'home', icon: '🏠', label: 'Home' },
  { page: 'learn', icon: '📚', label: 'Learn' },
  { page: 'practice', icon: '✏️', label: 'Practice' },
  { page: 'progress', icon: '📊', label: 'Progress' },
  { page: 'profile', icon: '👤', label: 'Profile' }
];

function renderNav(activePage) {
  const pills = NAV_ITEMS.map(item => `<button class="nav-pill ${item.page === activePage ? 'active' : ''}" onclick="router.navigate('${item.page}')"><span>${item.icon}</span><span class="nav-link-label">${item.label}</span></button>`).join('');

  document.getElementById('navigation').innerHTML = `
    <div class="nav-inner">
      <div class="logo">
        <span class="logo-icon">📖</span>
        <span class="logo-text">QUR'AN QUEST</span>
      </div>
      <div class="nav-actions">
        <button id="theme-toggle" class="theme-toggle" aria-label="Toggle theme">🌙</button>
      </div>
    </div>
    <div class="nav-pill-row">${pills}</div>
  `;

  themeManager.setupToggle();
}

function updateNavActive(activePage) {
  document.querySelectorAll('.nav-pill').forEach((pill, i) => {
    pill.classList.toggle('active', NAV_ITEMS[i].page === activePage);
  });
}

// Re-render the active pill whenever the router navigates, without
// rebuilding the whole nav (that would also drop the theme toggle listener
// churn unnecessarily).
const originalNavigate = Router.prototype.navigate;
Router.prototype.navigate = async function (pageName) {
  await originalNavigate.call(this, pageName);
  updateNavActive(pageName);
};

document.addEventListener('DOMContentLoaded', () => {
  renderNav('home');
  router.navigate('home');
});
